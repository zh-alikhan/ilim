/**
 * Sphere geometry utilities.
 *
 * We distribute N topic nodes evenly on a unit sphere using the
 * Fibonacci-sphere algorithm, then rotate and project them to 2D with a
 * simple perspective transform. All positioning is CSS-transform based —
 * no WebGL — so nodes remain real, accessible DOM elements.
 */

export interface SpherePoint {
  /** Unit-sphere coordinates (before rotation). */
  x: number;
  y: number;
  z: number;
}

export interface ProjectedNode {
  /** 2D screen offset from center, in px (scaled by radius). */
  screenX: number;
  screenY: number;
  /** Depth after rotation, range roughly [-1, 1]; higher = closer. */
  depth: number;
  /** Perspective scale factor for size/opacity. */
  scale: number;
}

/**
 * Generate `count` points spread evenly across a unit sphere.
 * Uses the golden-angle spiral for near-uniform distribution.
 */
export function fibonacciSphere(count: number): SpherePoint[] {
  const points: SpherePoint[] = [];
  const goldenAngle = Math.PI * (3 - Math.sqrt(5)); // ≈ 2.399963...

  for (let i = 0; i < count; i++) {
    // y goes from 1 down to -1
    const y = 1 - (i / (count - 1)) * 2;
    const radiusAtY = Math.sqrt(1 - y * y);
    const theta = goldenAngle * i;
    const x = Math.cos(theta) * radiusAtY;
    const z = Math.sin(theta) * radiusAtY;
    points.push({ x, y, z });
  }

  return points;
}

/**
 * Rotate a unit point by yaw (Y) then pitch (X). Returns rotated coords.
 * Shared by both the DOM topic nodes and the canvas particle field so they
 * spin in perfect lockstep.
 */
export function rotatePoint(
  point: SpherePoint,
  yaw: number,
  pitch: number,
): SpherePoint {
  const cosY = Math.cos(yaw);
  const sinY = Math.sin(yaw);
  const x1 = point.x * cosY - point.z * sinY;
  const z1 = point.x * sinY + point.z * cosY;
  const y1 = point.y;

  const cosX = Math.cos(pitch);
  const sinX = Math.sin(pitch);
  const y2 = y1 * cosX - z1 * sinX;
  const z2 = y1 * sinX + z1 * cosX;

  return { x: x1, y: y2, z: z2 };
}

/**
 * Rotate a point around the Y axis (yaw) then X axis (pitch),
 * and project to 2D with perspective.
 *
 * @param point       unit-sphere point
 * @param yaw         rotation around Y (radians)
 * @param pitch       rotation around X (radians)
 * @param radius      sphere radius in px
 * @param perspective camera distance in px (larger = flatter)
 */
export function projectPoint(
  point: SpherePoint,
  yaw: number,
  pitch: number,
  radius: number,
  perspective: number,
): ProjectedNode {
  // Rotate around Y axis (yaw)
  const cosY = Math.cos(yaw);
  const sinY = Math.sin(yaw);
  const x1 = point.x * cosY - point.z * sinY;
  const z1 = point.x * sinY + point.z * cosY;
  const y1 = point.y;

  // Rotate around X axis (pitch)
  const cosX = Math.cos(pitch);
  const sinX = Math.sin(pitch);
  const y2 = y1 * cosX - z1 * sinX;
  const z2 = y1 * sinX + z1 * cosX;
  const x2 = x1;

  // Perspective projection
  const denom = perspective + z2 * radius;
  const scale = perspective / Math.max(denom, 1);

  return {
    screenX: x2 * radius * scale,
    screenY: y2 * radius * scale,
    depth: z2,
    scale,
  };
}
