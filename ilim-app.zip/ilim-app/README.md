# Ilim — Authentic Islamic Knowledge

A curated digital library of authentic Islamic guidance for everyday life,
presented as a fast, elegant single-page application.

Grounded in the Quran, authentic hadith, and the words of respected scholars —
**57 topics** across **8 categories**, in **English, Russian, and Kazakh**.

---

## Tech stack

- **Next.js 14** (App Router) · **React 18** · **TypeScript** (strict)
- **Tailwind CSS** · **Framer Motion** · **next-intl** · **Lucide React**
- **ESLint** + **Prettier**

## Getting started

```bash
npm install
npm run dev      # runs the parser, then starts the dev server
```

The `predev` / `prebuild` hooks automatically run `scripts/parse.mjs`, which
regenerates `content/ilim.json` from the approved source markdown.

## Content integrity

The knowledge base is the **single source of truth**. The parser only
*restructures* the approved markdown into typed JSON — it never rewrites,
paraphrases, or invents content. Every Quran verse, hadith number, grade,
citation, and editorial summary is preserved exactly as written.

- Source: `scripts/source.md` (the approved trilingual knowledge base)
- Generated: `content/ilim.json` (do not edit by hand)

## Architecture

```
app/            Next.js App Router entry, root layout, global styles
components/
  layout/       Header, Footer, LanguageSwitcher, LocaleProvider
  sphere/       SphereNavigation, TopicNode  (CSS-3D, Phase 3)
  content/      ContentPanel + Quran/Hadith/Scholars/Lessons sections
  ui/           Primitives (RichText, Badge, …)
content/        ilim.json (source of truth) + schema.ts (types)
i18n/           Locale config, next-intl request, UI message catalogs
lib/            Typed content accessors, category metadata
hooks/          useMediaQuery, usePrefersReducedMotion, …
scripts/        parse.mjs (markdown → JSON)
```

### Key decisions

- **Single-page app.** One `selectedTopicId` state drives Home ↔ Topic views,
  animated with Framer Motion `AnimatePresence`. No route navigation.
- **Instant language switching.** A client `LocaleProvider` swaps both UI
  strings and knowledge-base content live, with no reload. Choice is persisted.
- **CSS-3D sphere (not WebGL).** 57 nodes placed via the Fibonacci-sphere
  algorithm and transformed in CSS. Real DOM nodes → keyboard focus, ARIA,
  crisp text, tiny bundle, great Core Web Vitals. Degrades gracefully under
  `prefers-reduced-motion`.

## Design system

| Token        | Value                               |
| ------------ | ----------------------------------- |
| Background   | `#FFFFFF` / `#F5F6F8`               |
| Text         | Charcoal `#1A1A1A`                  |
| Accent       | Gold `#C9A227` (`#D4AF37`,`#B8860B`)|
| Display font | Manrope                             |
| Body font    | Inter                               |

Gold is reserved for Quran verses, active topic, key headings, icons, and
hover states.

## Accessibility & performance

Semantic HTML, keyboard navigation, ARIA labels, visible focus states,
reduced-motion support, code-splitting of the sphere and content panel.
