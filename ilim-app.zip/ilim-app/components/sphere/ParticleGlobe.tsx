'use client';

import { useEffect, useRef } from 'react';
import { fibonacciSphere, rotatePoint, type SpherePoint } from '@/lib/sphere';

interface ParticleGlobeProps {
  /** Sphere radius in CSS px. */
  radius: number;
  /** Live rotation getters (refs) so the canvas spins with the DOM nodes. */
  getYaw: () => number;
  getPitch: () => number;
  /** Number of particles forming the shell. */
  count?: number;
}

interface Particle extends SpherePoint {
  /** Base brightness 0..1 (a few particles glow gold as "energy"). */
  energy: number;
  /** Small per-particle size jitter. */
  sizeSeed: number;
}

/**
 * A 3D particle globe rendered on a <canvas>, inspired by dense point-cloud
 * spheres. Adapted to Ilim's light theme: charcoal particles on white with
 * occasional gold "energy" points and faint connecting arcs near the front.
 *
 * Purely decorative (aria-hidden). The interactive, accessible topic labels
 * are separate DOM elements layered above this canvas.
 */
export function ParticleGlobe({
  radius,
  getYaw,
  getPitch,
  count = 1600,
}: ParticleGlobeProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const rafRef = useRef<number | null>(null);

  // Build the particle shell once (stable for the component's life).
  if (particlesRef.current.length === 0) {
    const base = fibonacciSphere(count);
    particlesRef.current = base.map((p, i) => {
      // Deterministic pseudo-random from index for stable rendering.
      const r = Math.sin(i * 12.9898) * 43758.5453;
      const frac = r - Math.floor(r);
      const r2 = Math.sin(i * 78.233) * 12543.123;
      const frac2 = r2 - Math.floor(r2);
      return {
        ...p,
        energy: frac < 0.06 ? 0.6 + frac2 * 0.4 : 0, // ~6% glow gold
        sizeSeed: 0.6 + frac2 * 0.9,
      };
    });
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let mounted = true;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const sizeCanvas = () => {
      const dim = radius * 2.15;
      canvas.width = dim * dpr;
      canvas.height = dim * dpr;
      canvas.style.width = `${dim}px`;
      canvas.style.height = `${dim}px`;
    };
    sizeCanvas();

    const perspective = radius * 3.2;

    const render = () => {
      if (!mounted) return;
      const yaw = getYaw();
      const pitch = getPitch();

      const w = canvas.width;
      const h = canvas.height;
      const cx = w / 2;
      const cy = h / 2;
      ctx.clearRect(0, 0, w, h);

      const particles = particlesRef.current;

      // Rotate + project all particles, collect for depth-sorted drawing.
      const projected = particles.map((p) => {
        const r = rotatePoint(p, yaw, pitch);
        const denom = perspective + r.z * radius;
        const scale = perspective / Math.max(denom, 1);
        return {
          x: cx + r.x * radius * scale * dpr,
          y: cy + r.y * radius * scale * dpr,
          z: r.z,
          scale,
          energy: p.energy,
          sizeSeed: p.sizeSeed,
        };
      });

      // Draw back-to-front so front particles sit on top.
      projected.sort((a, b) => a.z - b.z);

      for (const p of projected) {
        const depthNorm = (p.z + 1) / 2; // 0 back .. 1 front
        // Front particles: larger, more opaque. Back: tiny, faint.
        const size = Math.max(0.4, p.sizeSeed * (0.5 + depthNorm * 1.7) * dpr);
        const alpha = 0.12 + Math.pow(depthNorm, 1.5) * 0.72;

        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);

        if (p.energy > 0) {
          // Gold energy particle with a soft glow.
          ctx.fillStyle = `rgba(201, 162, 39, ${Math.min(1, alpha + 0.15)})`;
          ctx.shadowColor = 'rgba(201, 162, 39, 0.8)';
          ctx.shadowBlur = 6 * dpr * depthNorm;
        } else {
          // Charcoal particle (dark on light background).
          ctx.fillStyle = `rgba(26, 42, 74, ${alpha * 0.85})`;
          ctx.shadowBlur = 0;
        }
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      rafRef.current = requestAnimationFrame(render);
    };

    rafRef.current = requestAnimationFrame(render);

    const handleResize = () => sizeCanvas();
    window.addEventListener('resize', handleResize);

    return () => {
      mounted = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [radius, getYaw, getPitch]);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden
      className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
    />
  );
}
