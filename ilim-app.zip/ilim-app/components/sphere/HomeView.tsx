'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTranslations } from 'next-intl';
import { MousePointerClick } from 'lucide-react';
import { SphereNavigation } from '@/components/sphere/SphereNavigation';
import { useIsTouch } from '@/hooks/useMediaQuery';
import { premiumEase } from '@/lib/motion';

interface HomeViewProps {
  onSelect: (id: string) => void;
  activeId?: string | null;
  compact?: boolean;
}

export function HomeView({
  onSelect,
  activeId = null,
  compact = false,
}: HomeViewProps) {
  const t = useTranslations();
  const isTouch = useIsTouch();
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <motion.section
      layout
      transition={{ duration: 0.6, ease: premiumEase }}
      className={`mx-auto flex max-w-6xl flex-col items-center px-5 sm:px-8 ${
        compact ? 'pb-6 pt-6' : 'min-h-[calc(100dvh-4rem)] pb-8 pt-8 sm:pt-12'
      }`}
    >
      {/* Hero copy — subtitle removed per request. Condenses when compact. */}
      <motion.div
        layout
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: premiumEase, delay: 0.1 }}
        className={`max-w-2xl text-center ${compact ? 'mb-2' : 'mb-6'}`}
      >
        <p
          className={`font-semibold uppercase tracking-[0.2em] text-gold-deep transition-all ${
            compact ? 'text-xs' : 'mb-3 text-xs sm:text-sm'
          }`}
        >
          {t('hero.eyebrow')}
        </p>
        {!compact && (
          <h1 className="font-display text-display-xl font-extrabold leading-[1.02] tracking-tight text-ink text-balance">
            {t('hero.title')}
          </h1>
        )}
      </motion.div>

      {/* Sphere — sits lower on the page, shrinks when a topic is open. */}
      <motion.div
        layout
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, ease: premiumEase, delay: 0.2 }}
        className={`flex items-center justify-center ${
          compact ? '' : 'mt-6 flex-1 sm:mt-10'
        }`}
      >
        <SphereNavigation
          onSelect={onSelect}
          hoveredId={hoveredId}
          onHover={setHoveredId}
          activeId={activeId}
          compact={compact}
        />
      </motion.div>

      {/* Hint — hidden once a topic is open. */}
      {!compact && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-4 flex items-center gap-2 text-sm text-ink-muted"
        >
          <MousePointerClick className="h-4 w-4" aria-hidden />
          <span>{isTouch ? t('hero.hintTouch') : t('hero.hint')}</span>
        </motion.div>
      )}
    </motion.section>
  );
}
