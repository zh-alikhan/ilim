'use client';

import { memo } from 'react';
import type { ProjectedNode } from '@/lib/sphere';

interface TopicNodeProps {
  id: string;
  label: string;
  categoryId: string;
  projected: ProjectedNode;
  isHovered: boolean;
  isActive: boolean;
  isDimmed: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
}

/**
 * A floating topic label overlaid on the particle globe.
 *
 * Rendered as a real <button> (keyboard-focusable, screen-reader friendly).
 * Styled as bold black floating type — not a chip — to match the reference
 * aesthetic. Depth drives size, weight, opacity and blur for the 3D feel;
 * the active/hovered label lifts into a solid gold pill for clear affordance.
 */
function TopicNodeComponent({
  id,
  label,
  projected,
  isHovered,
  isActive,
  isDimmed,
  onSelect,
  onHover,
}: TopicNodeProps) {
  const { screenX, screenY, depth, scale } = projected;

  const depthNorm = (depth + 1) / 2; // 0 (far back) .. 1 (near front)
  const isBack = depth < -0.05;
  const highlighted = isHovered || isActive;

  // Opacity: front labels bold and clear; back labels recede sharply.
  let opacity: number;
  if (highlighted) {
    opacity = 1;
  } else if (isDimmed) {
    opacity = 0.1 + depthNorm * 0.14;
  } else {
    opacity = Math.pow(depthNorm, 1.5) * 0.9 + 0.12;
  }

  // Back labels blur/shrink so they never compete with readable front ones.
  const blur = isBack && !highlighted ? (1 - depthNorm) * 2.2 : 0;
  const fontScale = 0.74 + depthNorm * 0.42;

  const zIndex = highlighted ? 6000 : Math.round(depth * 1000) + 2000;
  const interactive = depth > -0.35 || highlighted;

  return (
    <button
      type="button"
      onClick={() => onSelect(id)}
      onMouseEnter={() => onHover(id)}
      onMouseLeave={() => onHover(null)}
      onFocus={() => onHover(id)}
      onBlur={() => onHover(null)}
      aria-label={label}
      aria-pressed={isActive}
      tabIndex={interactive ? 0 : -1}
      className="group absolute left-1/2 top-1/2 origin-center touch-manipulation select-none"
      style={{
        transform: `translate3d(calc(-50% + ${screenX}px), calc(-50% + ${screenY}px), 0) scale(${scale * fontScale})`,
        zIndex,
        opacity,
        filter: blur > 0.05 ? `blur(${blur}px)` : undefined,
        pointerEvents: interactive ? 'auto' : 'none',
        transition:
          'opacity 0.35s cubic-bezier(0.22,1,0.36,1), filter 0.3s ease',
        willChange: 'transform, opacity',
      }}
    >
      <span
        className={`inline-block whitespace-nowrap rounded-full leading-none backface-hidden transition-all duration-300 ${
          highlighted
            ? 'border border-gold bg-gold px-3.5 py-1.5 text-sm font-bold text-white shadow-gold-glow'
            : 'px-2 py-1 font-display text-sm font-bold tracking-tight text-ink group-hover:text-gold-deep'
        }`}
        style={
          highlighted
            ? undefined
            : {
                // Subtle white halo so black type stays legible over particles.
                textShadow:
                  '0 0 6px rgba(255,255,255,0.95), 0 0 2px rgba(255,255,255,1)',
              }
        }
      >
        {label}
      </span>
    </button>
  );
}

export const TopicNode = memo(TopicNodeComponent);
