'use client';

import { useMemo } from 'react';

/**
 * A soft, ambient starfield rendered behind the sphere to evoke a
 * "universe of knowledge." Purely decorative (aria-hidden), lightweight
 * CSS — no canvas or WebGL. Stars twinkle gently via CSS animation.
 */
export function Starfield({ radius }: { radius: number }) {
  const stars = useMemo(() => {
    const count = 46;
    const field = radius * 2.4;
    return Array.from({ length: count }, (_, i) => {
      // Distribute within a disc, biased toward the edges (halo look).
      const angle = Math.random() * Math.PI * 2;
      const dist = (0.35 + Math.random() * 0.65) * (field / 2);
      const x = Math.cos(angle) * dist;
      const y = Math.sin(angle) * dist;
      const size = 1 + Math.random() * 2.2;
      const delay = Math.random() * 4;
      const duration = 3 + Math.random() * 4;
      const bright = Math.random();
      return { x, y, size, delay, duration, bright, key: i };
    });
  }, [radius]);

  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 flex items-center justify-center"
    >
      {stars.map((s) => (
        <span
          key={s.key}
          className="absolute rounded-full"
          style={{
            width: s.size,
            height: s.size,
            transform: `translate(${s.x}px, ${s.y}px)`,
            background:
              s.bright > 0.7
                ? 'rgba(201,162,39,0.75)'
                : 'rgba(138,143,154,0.55)',
            boxShadow:
              s.bright > 0.7
                ? '0 0 6px rgba(201,162,39,0.6)'
                : '0 0 4px rgba(180,185,195,0.4)',
            animation: `twinkle ${s.duration}s ease-in-out ${s.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}
