'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocale } from '@/components/layout/LocaleProvider';
import { topics } from '@/lib/content';
import { fibonacciSphere, projectPoint } from '@/lib/sphere';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { usePrefersReducedMotion } from '@/hooks/usePrefersReducedMotion';
import { TopicNode } from './TopicNode';
import { SphereFallback } from './SphereFallback';
import { ParticleGlobe } from './ParticleGlobe';

interface SphereNavigationProps {
  onSelect: (id: string) => void;
  hoveredId: string | null;
  onHover: (id: string | null) => void;
  /** Currently opened topic (kept highlighted while content shows below). */
  activeId?: string | null;
  /** Shrinks the sphere when a topic is open and content is shown below. */
  compact?: boolean;
}

const DRAG_SENSITIVITY = 0.007;
const MAX_PITCH = Math.PI / 2.2;
const INERTIA_DECAY = 0.94;
const IDLE_SPIN = 0.0009; // gentle drift so the globe feels alive at rest

export function SphereNavigation({
  onSelect,
  hoveredId,
  onHover,
  activeId = null,
  compact = false,
}: SphereNavigationProps) {
  const { locale } = useLocale();
  const reducedMotion = usePrefersReducedMotion();
  const isCompactViewport = useMediaQuery('(max-width: 640px)');
  const isTablet = useMediaQuery('(max-width: 1024px)');

  // Responsive sphere sizing; shrink further when a topic is open.
  const baseRadius = isCompactViewport ? 150 : isTablet ? 205 : 255;
  const radius = compact ? baseRadius * 0.64 : baseRadius;
  const perspective = isCompactViewport ? 640 : 940;

  // Base sphere points for the topic labels (stable across renders).
  const basePoints = useMemo(() => fibonacciSphere(topics.length), []);

  // Rotation state in refs to avoid re-renders inside the RAF loop.
  const yawRef = useRef(0.3);
  const pitchRef = useRef(-0.12);
  const [, forceRender] = useState(0);

  // Live getters so the particle canvas spins in lockstep with the labels.
  const getYaw = useCallback(() => yawRef.current, []);
  const getPitch = useCallback(() => pitchRef.current, []);

  // Interaction state.
  const pointerDownRef = useRef(false);
  const draggingRef = useRef(false);
  const startPointer = useRef({ x: 0, y: 0 });
  const lastPointer = useRef({ x: 0, y: 0 });
  const capturedRef = useRef<number | null>(null);
  const velocityRef = useRef({ yaw: 0, pitch: 0 });
  const rafRef = useRef<number | null>(null);

  // Animation loop: idle drift + inertia after a drag.
  useEffect(() => {
    if (reducedMotion) return;
    let mounted = true;

    const tick = () => {
      if (!mounted) return;
      const v = velocityRef.current;

      if (!draggingRef.current) {
        const hasMomentum =
          Math.abs(v.yaw) > 0.00002 || Math.abs(v.pitch) > 0.00002;
        if (hasMomentum) {
          yawRef.current += v.yaw;
          pitchRef.current += v.pitch;
          v.yaw *= INERTIA_DECAY;
          v.pitch *= INERTIA_DECAY;
        } else {
          // Gentle idle spin so the globe never looks frozen.
          yawRef.current += IDLE_SPIN;
        }
      }

      pitchRef.current = Math.max(
        -MAX_PITCH,
        Math.min(MAX_PITCH, pitchRef.current),
      );

      forceRender((n) => (n + 1) % 1000000);
      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      mounted = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [reducedMotion]);

  // Pointer handlers — click vs drag: don't capture until movement threshold,
  // so a plain click/tap on a topic label opens it, while drag rotates.
  const DRAG_THRESHOLD = 5;

  const handlePointerDown = useCallback((e: React.PointerEvent) => {
    pointerDownRef.current = true;
    draggingRef.current = false;
    startPointer.current = { x: e.clientX, y: e.clientY };
    lastPointer.current = { x: e.clientX, y: e.clientY };
    velocityRef.current = { yaw: 0, pitch: 0 };
  }, []);

  const handlePointerMove = useCallback((e: React.PointerEvent) => {
    if (!pointerDownRef.current) return;

    if (!draggingRef.current) {
      const totalDx = e.clientX - startPointer.current.x;
      const totalDy = e.clientY - startPointer.current.y;
      if (Math.hypot(totalDx, totalDy) < DRAG_THRESHOLD) return;
      draggingRef.current = true;
      try {
        (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
        capturedRef.current = e.pointerId;
      } catch {
        capturedRef.current = null;
      }
    }

    const dx = e.clientX - lastPointer.current.x;
    const dy = e.clientY - lastPointer.current.y;
    lastPointer.current = { x: e.clientX, y: e.clientY };

    const dYaw = dx * DRAG_SENSITIVITY;
    const dPitch = dy * DRAG_SENSITIVITY;
    yawRef.current += dYaw;
    pitchRef.current += dPitch;
    velocityRef.current = { yaw: dYaw, pitch: dPitch };
  }, []);

  const handlePointerUp = useCallback((e: React.PointerEvent) => {
    pointerDownRef.current = false;
    draggingRef.current = false;
    if (capturedRef.current !== null) {
      try {
        (e.currentTarget as Element).releasePointerCapture?.(
          capturedRef.current,
        );
      } catch {
        /* no-op */
      }
      capturedRef.current = null;
    }
  }, []);

  // Reduced-motion: render an accessible grouped fallback instead.
  if (reducedMotion) {
    return <SphereFallback onSelect={onSelect} />;
  }

  const yaw = yawRef.current;
  const pitch = pitchRef.current;

  // Depth-sorted topic labels (painter's algorithm) so front labels sit on top.
  const rendered = basePoints
    .map((point, i) => ({
      topic: topics[i],
      projected: projectPoint(point, yaw, pitch, radius, perspective),
    }))
    .sort((a, b) => a.projected.depth - b.projected.depth);

  const frameSize = radius * 2 + (compact ? 96 : 170);

  return (
    <div
      className="scene-3d relative mx-auto flex touch-none select-none items-center justify-center"
      style={{
        width: frameSize,
        height: frameSize,
        maxWidth: '100%',
        cursor: draggingRef.current ? 'grabbing' : 'grab',
        transition:
          'width 0.6s cubic-bezier(0.22,1,0.36,1), height 0.6s cubic-bezier(0.22,1,0.36,1)',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
      role="group"
      aria-label="Topic globe. Drag to rotate, select a topic to explore."
    >
      {/* Soft ambient glow behind the globe */}
      <div
        aria-hidden
        className="pointer-events-none absolute rounded-full"
        style={{
          width: radius * 2.5,
          height: radius * 2.5,
          background:
            'radial-gradient(circle, rgba(201,162,39,0.08) 0%, rgba(26,42,74,0.04) 40%, transparent 70%)',
        }}
      />

      {/* Animated 3D particle globe (canvas, decorative) */}
      <ParticleGlobe radius={radius} getYaw={getYaw} getPitch={getPitch} />

      {/* Floating, interactive topic labels layered above the particles */}
      {rendered.map(({ topic, projected }) => (
        <TopicNode
          key={topic.id}
          id={topic.id}
          label={topic.translations[locale].name}
          categoryId={topic.categoryId}
          projected={projected}
          isHovered={hoveredId === topic.id}
          isActive={activeId === topic.id}
          isDimmed={
            (hoveredId !== null && hoveredId !== topic.id) ||
            (activeId !== null && activeId !== topic.id && hoveredId === null)
          }
          onSelect={onSelect}
          onHover={onHover}
        />
      ))}
    </div>
  );
}
